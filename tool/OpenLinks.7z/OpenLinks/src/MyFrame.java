import com.sun.org.apache.bcel.internal.generic.NEW;

/**
 * @Auther lmy
 * @date 2023-08-26 17:45
 * @Description 批量打开超链接
 */
public class MyFrame {
    public static void main(String[] args) {
        OpenLinks openLinks = new OpenLinks();


    }


}
